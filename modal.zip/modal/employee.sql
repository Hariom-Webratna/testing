CREATE TABLE `employee` (
  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `emp_name` varchar(100) NOT NULL,
  `salary` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `city` varchar(80) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `employee` (`id`, `emp_name`, `salary`, `gender`, `city`, `email`) VALUES
(1, 'Bikash', '13000', 'male', 'Kanpur', 'phpcodertech@gmail.com'),
(2, 'Vishal', '12800', 'male', 'Pune', 'phpcodertech@gmail.com'),
(3, 'Vijay', '5000', 'male', 'Jaipur', 'phpcodertech@gmail.com'),
(4, 'Rahul', '2500', 'male', 'Kanpur', 'phpcodertech@gmail.com');