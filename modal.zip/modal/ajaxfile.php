<?php
include "config.php";

$userid = $_POST['userid'];

$sql = "select * from employee where id=".$userid;
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
?>
<form role="form" method="POST" action="#" enctype="multipart/form-data">
            <div class="form-group">
              <label for="category"><span class="glyphicon glyphicon-user"></span> Name </label>
              <input type="text" class="form-control" name="category" id="category" value="<?php echo $row['emp_name'];?>">
              <input type="hidden" name="main_id" value="<?php echo $id;?>">
            </div>
            <div class="form-group">
              <label for="bname"><span class="glyphicon glyphicon-eye-open"></span> Salary </label>
              <input type="text" class="form-control" name="bname" value="<?php echo $row['salary'];?>">
            </div>
            <div class="form-group">
              <label for="aname"><span class="glyphicon glyphicon-eye-open"></span> Gender </label>
              <input type="text" class="form-control" name="aname" value="<?php echo $row['gender'];?>">
            </div>
            <div class="form-group">
              <label for="bookid"><span class="glyphicon glyphicon-eye-open"></span> City </label>
              <input type="text" class="form-control" name="bookid" value="<?php echo  $row['city'];?>">
            </div>
            <div class="form-group">
              <label for="bookid"><span class="glyphicon glyphicon-eye-open"></span> Email </label>
              <input type="text" class="form-control" name="bookid" value="<?php echo  $row['email'];?>">
            </div>
        </form>

<button type="button" name="btn" id="btn" onclick="updatedata(<?php echo $row['id'];?>)">update</button>

<script>
  function updatedata(id){
    var category = $("#category").val();

    $.ajax({
      url: 'update.php',
      type: 'POST',
      data:{
        category : category,
        id:id
      },
      success:function(data)
      {
        alert(data);
      }
      });

  }
</script>
