<?php
include "config.php";

if (isset($_POST))
{
extract($_POST);

$qry = mysqli_query($con, "SELECT * FROM employee WHERE id = '$id' ");


if (mysqli_query($con, "UPDATE employee SET emp_name = '$category' WHERE ID = '$id' "))
{
echo 1;
}
else {
echo mysqli_error($con);
}
}
?>
